public class HeartRateTest {

    /**
     *
     * Main
     *
     * @param args  the args.
     */
    public static void main(String[] args) {

        try {
            HeartRate hr = new HeartRate(30,37, 37.4);
            HeartRateCalculator hrc = new HeartRateCalculator(hr);

            System.out.println("Body Temperature: " + hrc.getHeartRate().getBodyTemperature());
            System.out.println("Physiological Rate: " + hrc.getHeartRate().getPhysiologicalRate());
            System.out.println("Heart Rate: " + hrc.getHeartRate().getHeartRate());
            System.out.println("Max Heart Rate: " + hrc.calculateTargetHRMax());
            System.out.println("Target Heart Rate Range: " + hrc.calculateTargetHRMin() + " - " + hrc.calculateTargetHRMax());
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
