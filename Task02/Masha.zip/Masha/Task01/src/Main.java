import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 * The class Main
 */
public class Main {


    /**
     *
     * Main
     *
     * @param args  the args.
     */
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        List<HeartRate> heartRateList = new ArrayList<>(); // колекція для збереження об'єктів

        System.out.print("Введіть кількість обчислень: ");
        int count = scanner.nextInt();
        scanner.nextLine(); // очищаємо буфер

        for (int i = 1; i <= count; i++) {
            System.out.println("Обчислення №" + i);
            System.out.print("Введіть вік: ");
            int age = scanner.nextInt();
            System.out.print("Введіть ЧСС у стані спокою: ");
            int physiologicalRate = scanner.nextInt();
            System.out.print("Введіть температуру тіла: ");
            double bodyTemperature = scanner.nextDouble();
            scanner.nextLine(); // очищаємо буфер

            HeartRate heartRate = new HeartRate(age, physiologicalRate, bodyTemperature);
            heartRateList.add(heartRate); // додаємо об'єкт до колекції
        }

        System.out.println("Список обчислень:");
        for (HeartRate heartRate : heartRateList) {
            System.out.println(heartRate.toString()); // виводимо об'єкти зі списку
        }

    }

}
