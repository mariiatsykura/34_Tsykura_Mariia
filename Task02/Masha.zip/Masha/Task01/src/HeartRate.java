import java.io.Serializable;

import java.io.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


/**
 * The class Heart rate implements serializable
 */
public class HeartRate implements Serializable {
    private static final long serialVersionUID = 1L;
    private double bodyTemperature; // температура тіла людини


    /**
     *
     * норма
     *
     * @param серцебиття  the серцебиття.
     * @return фізіологічна
     * @throws
    private int restingHR; // частота серцебиття у стані спокою
    private int maxHR; // максимально можлива частота серцебиття
    private int heartRate; // обчислена частота серцебиття

    public HeartRate(int age
     * @throws  int restingHR
     * @throws  double bodyTemperature
     */
    private int physiologicalRate; // індивідуальна фізіологічна норма (частота серцебиття)
    private int restingHR; // частота серцебиття у стані спокою
    private int maxHR; // максимально можлива частота серцебиття
    private int heartRate; // обчислена частота серцебиття

    public HeartRate(int age, int restingHR, double bodyTemperature) {

        this.restingHR = restingHR;
        this.bodyTemperature = bodyTemperature;
        this.maxHR = 220 - age;
        this.physiologicalRate = calculatePhysiologicalRate(age);
        calculateHeartRate();
    }


    /**
     *
     * Gets the body temperature
     *
     * @return the body temperature
     */
    public double getBodyTemperature() {

        return bodyTemperature;
    }


    /**
     *
     * Gets the physiological rate
     *
     * @return the physiological rate
     */
    public int getPhysiologicalRate() {

        return physiologicalRate;
    }


    /**
     *
     * Gets the resting HR
     *
     * @return the resting HR
     */
    public int getRestingHR() {

        return restingHR;
    }


    /**
     *
     * Gets the max HR
     *
     * @return the max HR
     */
    public int getMaxHR() {

        return maxHR;
    }


    /**
     *
     * Gets the heart rate
     *
     * @return the heart rate
     */
    public int getHeartRate() {

        return heartRate;
    }


    /**
     *
     * Gets the target HR max
     *
     * @return the tar HR max
     */
    public int getTargetHRMax() {

        return (int) ((maxHR - restingHR) * 0.5 + restingHR);
    }


    /**
     *
     * Gets the target HR min
     *
     * @return the tar HR min
     */
    public int getTargetHRMin() {

        return restingHR;
    }


    /**
     *
     * Calculate physiological rate
     *
     * @param age  the age.
     * @return int
     */
    private int calculatePhysiologicalRate(int age) {

        return age <= 30 ? 80 : age <= 35 ? 78 : age <= 40 ? 75 : age <= 45 ? 73 : age <= 50 ? 70 : age <= 55 ? 68 : age <= 60 ? 65 : age <= 65 ? 63 : age <= 70 ? 60 : 58;
    }


    /**
     *
     * Calculate heart rate
     *
     */
    private void calculateHeartRate() {

        int rate = physiologicalRate + (int) ((bodyTemperature - 36.6) * 10);
        heartRate = Math.max(rate, 0); // серцебиття не може бути від'ємним
    }


    /**
     *
     * Save heart rates
     *
     * @param heartRates  the heart rates.
     * @param filename  the filename.
     */
    public static void saveHeartRates(List<HeartRate> heartRates, String filename) {

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(heartRates);
        } catch (IOException e) {
            System.out.println("Помилка збереження даних у файл " + filename);
        }
    }


    /**
     *
     * Load heart rates
     *
     * @param filename  the filename.
     * @return List<HeartRate>
     */
    public static List<HeartRate> loadHeartRates(String filename) {

        List<HeartRate> heartRates = new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            heartRates = (List<HeartRate>) in.readObject();
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("Помилка завантаження даних з файлу " + filename);
        }
        return heartRates;
    }
}
