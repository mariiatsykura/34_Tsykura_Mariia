class HeartRateCalculator {
    private HeartRate heartRate;


    /**
     *
     * It is a constructor.
     *
     * @param heartRate  the heart rate.
     */
    public HeartRateCalculator(HeartRate heartRate) {

        this.heartRate = heartRate;
    }


    /**
     *
     * It is a constructor.
     *
     * @param age  the age.
     * @param restingHR  the resting HR.
     * @param bodyTemp  the body temp.
     * @throws   IllegalArgumentException
     */
    public HeartRateCalculator(int age, int restingHR, int bodyTemp) throws IllegalArgumentException {

        this.heartRate = new HeartRate(age, bodyTemp, restingHR);
    }


    /**
     *
     * It is a constructor.
     *
     */
    public HeartRate getHeartRate() {

        return heartRate;
    }


    /**
     *
     * It is a constructor.
     *
     * @param heartRate  the heart rate.
     */
    public void setHeartRate(HeartRate heartRate) {

        this.heartRate = heartRate;
    }


    /**
     *
     * It is a constructor.
     *
     */
    public int calculateTargetHRMin() {

        return heartRate.getTargetHRMin();
    }


    /**
     *
     * It is a constructor.
     *
     */
    public int calculateTargetHRMax() {

        return heartRate.getTargetHRMax();
    }
}
